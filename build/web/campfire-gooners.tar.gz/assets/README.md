# campfire-gooners
Digging In Paris – a small pygame mining game.

## Packaging for itch.io with `pygbag`

This project is structured so it can be built into a web executable via
[pygbag](https://github.com/pygame-web/pygbag).  The helper script
`package.ps1` and `requirements.txt` are provided to simplify the process.

### Quick start

1. Create/activate a Python environment.
2. Install dependencies:
   ```sh
   pip install -r requirements.txt pygbag
   ```
3. Run the packager (PowerShell):
   ```powershell
   .\package.ps1
   ```

This will generate a `dist/` directory containing the WASM/HTML build that
can be uploaded to itch.io.  Adjust the command-line flags in
`package.ps1` if you need to include additional assets or change the
output folder.

## Development

Run the game locally with:

```sh
python main.py
```

and edit the source files as desired.
